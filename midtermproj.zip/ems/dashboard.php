<?php include("auth_session.php"); ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Event Registration System</title>
    <link rel="icon" href="includes/favicon.ico" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">
    <link href="includes/plugins/bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="includes/plugins/node-waves/waves.css" rel="stylesheet" />
    <link href="includes/plugins/animate-css/animate.css" rel="stylesheet" />
    <link href="includes/plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css" rel="stylesheet">
    <link href="includes/css/style.css" rel="stylesheet">
    <link href="includes/css/themes/all-themes.css" rel="stylesheet" />
    <!-- DataTables Buttons CSS -->
    <link href="https://cdn.datatables.net/buttons/1.7.1/css/buttons.dataTables.min.css" rel="stylesheet">
</head>

<body class="theme-red">
    <?php include("nav.php"); ?>

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>
                    Event Registration System
                    <small>Manage your Events</small>
                </h2>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Events
                            </h2>
                            <ul class="header-dropdown m-r--5">
                                <a href="add_event.php" class="btn btn-primary float-right">Add New Event</a>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <?php
                                include_once 'db.php';
                                $result = mysqli_query($conn, "SELECT * FROM events");
                                ?>

                                <?php
                                if (mysqli_num_rows($result) > 0) {
                                ?>
                                    <table id="event_table" class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                        <thead>
                                            <tr>
                                                <th>Event ID</th>
                                                <th>Client Name</th>
                                                <th>Event Name</th>
                                                <th>Date</th>
                                                <th>Location</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th>Event ID</th>
                                                <th>Client Name</th>
                                                <th>Event Name</th>
                                                <th>Date</th>
                                                <th>Location</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            <?php while ($row = mysqli_fetch_array($result)) { ?>
                                                <tr>
                                                    <td><?php echo $row["event_id"]; ?></td>
                                                    <td><?php echo $row["client_name"]; ?></td> <!-- Display client name here -->
                                                    <td><?php echo $row["event_name"]; ?></td>
                                                    <td><?php echo $row["event_date"]; ?></td>
                                                    <td><?php echo $row["event_location"]; ?></td>
                                                    <td>
                                                        <a href="view_event.php?id=<?php echo $row["event_id"]; ?>" class="btn btn-primary" title='View Event'>View</a>
                                                        <a href="update_event.php?id=<?php echo $row["event_id"]; ?>" class="btn btn-success" title='Update Event'>Update</a>
                                                        <button class="btn btn-danger delete-event" data-id="<?php echo $row["event_id"]; ?>" title='Delete Event'>Delete</button>
                                                    </td>
                                                </tr>
                                            <?php } ?>

                                        </tbody>

                                    </table>
                                <?php
                                } else {
                                    echo "No events found";
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="includes/plugins/jquery/jquery.min.js"></script>
    <script src="includes/plugins/bootstrap/js/bootstrap.js"></script>
    <script src="includes/plugins/node-waves/waves.js"></script>
    <script src="includes/plugins/jquery-datatable/jquery.dataTables.js"></script>
    <script src="includes/plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
    <script src="includes/js/admin.js"></script>
    <script src="includes/js/pages/tables/jquery-datatable.js"></script>
    <!-- DataTables Buttons JS -->
    <script src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>
    <!-- DataTables Print Button JS -->
    <script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.print.min.js"></script>
    <script>
        $(document).ready(function() {
            // Destroy existing DataTable before reinitializing
            if ($.fn.DataTable.isDataTable('#event_table')) {
                $('#event_table').DataTable().destroy();
            }

            $('#event_table').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'excel', 'csv', 'pdf', 'print'
                ]
            });

            // Delete Event Confirmation
            $('.delete-event').click(function() {
                var eventId = $(this).data('id');
                if (confirm("Are you sure you want to delete this event?")) {
                    window.location.href = 'delete_event.php?id=' + eventId;
                }
            });
        });
    </script>
</body>

</html>
