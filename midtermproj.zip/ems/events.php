<?php
include_once 'db.php';
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Events</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .events-container {
            width: 50%;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .event-item {
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .event-item:hover {
            background-color: #e5e5e5;
        }
        .event-name {
            font-weight: bold;
            margin-bottom: 5px;
        }
        .event-date {
            color: #666;
        }
    </style>
</head>
<body>
    <h2>Events</h2>
    <div class="events-container">
        <?php
        $query = "SELECT * FROM events";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<div class="event-item">';
                echo '<div class="event-name">' . $row["event_name"] . '</div>';
                echo '<div class="event-date">Date: ' . $row["event_date"] . '</div>';
                echo '<div class="event-location">Location: ' . $row["event_location"] . '</div>';
                echo '</div>';
            }
        } else {
            echo "No events found";
        }
        ?>
    </div>
</body>
</html>
