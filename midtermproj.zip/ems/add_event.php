<?php
// Include database connection file
include_once 'db.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $clientName = $_POST['client_name'];
    $eventName = $_POST['event_name'];
    $eventDate = $_POST['event_date'];
    $eventLocation = $_POST['event_location'];

    // Insert event data into database
    $query = "INSERT INTO events (client_name, event_name, event_date, event_location) VALUES ('$clientName', '$eventName', '$eventDate', '$eventLocation')";
    $result = mysqli_query($conn, $query);

    // Check if insertion was successful
    if ($result) {
        // Redirect to event dashboard page with success parameter
        header("Location: dashboard.php?success=true");
        exit();
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}

// Fetch event categories from the database
$query_categories = "SELECT * FROM event_categories";
$result_categories = mysqli_query($conn, $query_categories);
$categories = mysqli_fetch_all($result_categories, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Add New Event</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        h2 {
            text-align: center;
            color: #333;
            margin-top: 20px;
        }
        form {
            width: 50%;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
            color: #333;
        }
        input[type="text"],
        select,
        input[type="date"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
            font-size: 16px;
            color: #555;
        }
        input[type="submit"] {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 5px;
            background-color: #4caf50;
            color: #fff;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h2>Add New Event</h2>
    <form id="event_form" method="post" onsubmit="return confirm('Are you sure you want to submit this event?');">
        <label for="client_name">Your Name:</label>
        <input type="text" id="client_name" name="client_name" required>

        <label for="event_name">Event Name:</label>
        <select id="event_name" name="event_name" required>
            <option value="" disabled selected>Select Event</option>
            <?php foreach ($categories as $category): ?>
                <option value="<?php echo $category['category_name']; ?>"><?php echo $category['category_name']; ?></option>
            <?php endforeach; ?>
        </select>

        <label for="event_date">Date:</label>
        <input type="date" id="event_date" name="event_date" required>

        <label for="event_location">Location:</label>
        <input type="text" id="event_location" name="event_location" required>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
