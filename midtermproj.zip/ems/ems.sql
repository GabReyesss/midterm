-- Create the database
CREATE DATABASE IF NOT EXISTS ems;

-- Switch to the created database
USE ems;

-- Table for Users
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role ENUM('admin', 'organizer', 'participant') NOT NULL
);

-- Table for Clients
CREATE TABLE IF NOT EXISTS clients (
    client_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    address VARCHAR(255)
);

-- Table for Event Categories
CREATE TABLE IF NOT EXISTS event_categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) UNIQUE NOT NULL
);

-- Inserting sample event categories
INSERT INTO event_categories (category_name) VALUES
('Birthday'),
('Wedding'),
('Anniversary'),
('Graduation'),
('Corporate Event'),
('Holiday Celebration'),
('Religious Ceremony'),
('Family Reunion'),
('Charity Event'),
('Concert'),
('Conference'),
('Workshop'),
('Exhibition'),
('Sporting Event');


-- Table for Events
CREATE TABLE IF NOT EXISTS events (
    event_id INT AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(255) NOT NULL,
    event_date DATE NOT NULL,
    event_time TIME NOT NULL,
    venue VARCHAR(255) NOT NULL,
    description TEXT,
    organizer_id INT,
    category_id INT,
    client_id INT, -- Added client_id column
    FOREIGN KEY (organizer_id) REFERENCES users(user_id),
    FOREIGN KEY (category_id) REFERENCES event_categories(category_id),
    FOREIGN KEY (client_id) REFERENCES clients(client_id) -- Foreign key relationship with clients table
);

-- Table for Event Registrations
CREATE TABLE IF NOT EXISTS event_registrations (
    registration_id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    participant_id INT NOT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES events(event_id),
    FOREIGN KEY (participant_id) REFERENCES users(user_id)
);
