<?php
// Include database connection file
include_once 'db.php';

// Check if event ID is provided in the URL
if(isset($_GET['id'])) {
    // Retrieve event ID from URL
    $eventId = $_GET['id'];

    // Delete event from the database
    $deleteQuery = "DELETE FROM events WHERE event_id = $eventId";
    $deleteResult = mysqli_query($conn, $deleteQuery);

    // Check if deletion was successful
    if ($deleteResult) {
        // Redirect to dashboard page after deletion
        header("Location: dashboard.php"); // Change 'dashboard.php' to your actual dashboard page
        exit();
    } else {
        // Error handling, if deletion fails
        echo "Error deleting event: " . mysqli_error($conn);
    }
} else {
    // Event ID not provided
    echo "Event ID not provided.";
}
?>
